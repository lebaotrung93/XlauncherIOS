//
//  XLauncher.h
//  XLauncher
//
//  Created by Loc Nguyen Tan on 8/2/16.
//  Copyright © 2016 XCT. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for XLauncher.
FOUNDATION_EXPORT double XLauncherVersionNumber;

//! Project version string for XLauncher.
FOUNDATION_EXPORT const unsigned char XLauncherVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XLauncher/PublicHeader.h>

#import "XDefine.h"



@interface XLauncher : NSObject
@property (nonatomic, readonly) BOOL isSetup;

// singleton
+ (id)getInstance;

// setup
- (void)setupWithWindow:(UIWindow *)window;
- (void)setDomainDebug:(BOOL)debug;

// for launcher
- (void)setLauncherStickySide:(ATButtonStickySide)side;
- (void)showButtonLauncherWithAnimation:(BOOL)anim;
- (void)hideButtonLauncherWithAnimation:(BOOL)anim;
- (void)showLoginScreen;
- (void)showPaymentScreen;
- (BOOL)silentLogin;
- (void)setGameOrder:(NSString *)gameOrder;
// for callback
- (void)setPaymentExtraDataObject:(NSObject<PaymentExtraDataProtocol> *)object;
- (void)handleLoginWithCompletion:(void (^) (NSDictionary *data))completion;
- (void)handleLogoutWithCompletion:(void (^) ())completion;
- (void)handlePaymentWithCompletion:(void (^) (NSDictionary *data))completion;
- (void)handleShowSDKCompletion:(void (^)())completion;
- (void)handleCloseSDKCompletion:(void (^)())completion;
// for orientation
- (BOOL)isScreenRotateToPortrait;

// for internal usage
- (NSString *)getPaymentExtraData;
// setKey
- (void)setAppsFlyerDevKey:(NSString *)devKey appID:(NSString *)appID;
- (void)setACTConversionID:(NSString *)conversionID andLabel:(NSString *)label andValue:(NSString *)value;
- (void)setGoogleAnalyticsID:(NSString *)analyticsID;
@end
